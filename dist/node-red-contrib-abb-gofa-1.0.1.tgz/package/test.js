'use strict';
var assert = require('assert');
var fs     = require('fs');
var os     = require('os');
var path   = require('path');
var http   = require('http');
var robot  = require('./nodes/gofa-robot');
var gotoToken           = robot.gotoToken;
var parseXhtml          = robot.parseXhtml;
var atomicWriteFileSync = robot.atomicWriteFileSync;
var fileMtimeMs         = robot.fileMtimeMs;
var resolveMoveType     = robot.resolveMoveType;
var createRobotClient   = robot.createRobotClient;
var patchServerIp       = require('./nodes/gofa-upload-mod').patchServerIp;
var parseLiSpans        = require('./nodes/gofa-rapid-tasks').parseLiSpans;

var passed = 0, failed = 0;
function check(label, fn) {
    try { fn(); console.log('PASS ' + label); passed++; }
    catch(e) { console.error('FAIL ' + label + ' — ' + e.message); failed++; }
}
function checkAsync(label, fn) {
    return Promise.resolve().then(fn).then(function() {
        console.log('PASS ' + label); passed++;
    }, function(e) {
        console.error('FAIL ' + label + ' — ' + e.message); failed++;
    });
}

// ── minimal Node-RED harness — enough to instantiate/drive a node module
// without pulling in the real Node-RED runtime ──────────────────────────────
function loadNodeType(modulePath, opts) {
    opts = opts || {};
    var Ctor;
    var fakeRED = {
        nodes: {
            createNode: function(node, config) {
                node.credentials = config.credentials || {};
                node._handlers = {};
                node.on     = function(evt, fn) { node._handlers[evt] = fn; return node; };
                node.warnings = []; node.errors = []; node.statuses = []; node.sent = [];
                node.warn   = function(m) { node.warnings.push(m); };
                node.error  = function(m) { node.errors.push(m); };
                node.status = function(s) { node.statuses.push(s); };
                node.send   = function(m) { node.sent.push(m); };
            },
            getNode:      function(id) { return (opts.nodesById || {})[id] || null; },
            registerType: function(type, C) { Ctor = C; }
        },
        settings: { userDir: opts.userDir || os.tmpdir() },
        util:     { cloneMessage: function(m) { return JSON.parse(JSON.stringify(m)); } },
        httpAdmin: { get: function() {} },
        auth:      { needsPermission: function() { return function() {}; } }
    };
    require(modulePath)(fakeRED);
    return Ctor;
}
// Drives a node's 'input' handler like the runtime would; resolves with
// whatever the node passed to done(err).
function runInput(node, msg) {
    return new Promise(function(resolve) {
        node._handlers['input'](msg, function(m) { node.sent.push(m); }, function(err) { resolve(err); });
    });
}

var tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'gofa-test-'));

var sample = { x: 323.219, y: -81.812, z: 807.001,
               q1: 0.26714, q2: 0.12904, q3: 0.95361, q4: -0.05281,
               cf1: -1, cf4: -1, cf6: 0, cfx: 0 };

check('gotoToken: valid target produces GOTOJ string by default', function() {
    var tok = gotoToken(sample);
    assert.ok(tok.startsWith('GOTOJ'), 'should start with GOTOJ');
    assert.ok(tok.split(';').length === 11, 'should have 11 semicolon-separated values');
});

check('gotoToken: moveType "L" produces GOTOL string', function() {
    var tok = gotoToken(sample, 'L');
    assert.ok(tok.startsWith('GOTOL'), 'should start with GOTOL');
});

check('gotoToken: unrecognized moveType falls back to GOTOJ', function() {
    var tok = gotoToken(sample, 'bogus');
    assert.ok(tok.startsWith('GOTOJ'), 'should start with GOTOJ');
});

check('resolveMoveType: passes through "J" and "L"', function() {
    assert.strictEqual(resolveMoveType('J', 'L'), 'J');
    assert.strictEqual(resolveMoveType('L', 'J'), 'L');
});
check('resolveMoveType: falls back on anything else', function() {
    assert.strictEqual(resolveMoveType('bogus', 'J'), 'J');
    assert.strictEqual(resolveMoveType(undefined, 'J'), 'J');
    assert.strictEqual(resolveMoveType(null, 'L'), 'L');
});

check('gotoToken: xyz rounds to 1 decimal place', function() {
    var tok = gotoToken(sample);
    var parts = tok.slice(5).split(';');
    assert.strictEqual(parts[0], '323.2');
    assert.strictEqual(parts[1], '-81.8');
    assert.strictEqual(parts[2], '807.0');
});

check('gotoToken: quaternion rounds to 4 decimal places', function() {
    var tok = gotoToken(sample);
    var parts = tok.slice(5).split(';');
    assert.strictEqual(parts[3], '0.2671');
    assert.strictEqual(parts[4], '0.1290');
    assert.strictEqual(parts[5], '0.9536');
    assert.strictEqual(parts[6], '-0.0528');
});

check('gotoToken: config flags are integers', function() {
    var tok = gotoToken(sample);
    var parts = tok.slice(5).split(';');
    assert.strictEqual(parts[7],  '-1');
    assert.strictEqual(parts[8],  '-1');
    assert.strictEqual(parts[9],  '0');
    assert.strictEqual(parts[10], '0');
});

check('gotoToken: returns null when any value is NaN', function() {
    var bad = Object.assign({}, sample, { q1: NaN });
    assert.strictEqual(gotoToken(bad), null);
});

check('gotoToken: returns null when any value is Infinity', function() {
    var bad = Object.assign({}, sample, { z: Infinity });
    assert.strictEqual(gotoToken(bad), null);
});

check('parseXhtml: extracts value for matching class', function() {
    var body = '<span class="ctrlstate">motoron</span>';
    assert.strictEqual(parseXhtml(body, 'ctrlstate'), 'motoron');
});

check('parseXhtml: trims whitespace', function() {
    var body = '<span class="speedratio">  75  </span>';
    assert.strictEqual(parseXhtml(body, 'speedratio'), '75');
});

check('parseXhtml: returns null when class not found', function() {
    var body = '<span class="other">value</span>';
    assert.strictEqual(parseXhtml(body, 'ctrlstate'), null);
});

// ── gofa-rapid-tasks: parseLiSpans (real RWS response samples) ──────────────
var tasksBody = '<ul><li class="rap-task-li" title="SC_CBC"> <a href="tasks/SC_CBC" rel="self"></a> <span class="name">SC_CBC</span> <span class="type">semistatic</span><span class="taskstate">initiated</span><span class="excstate">started</span></li> <li class="rap-task-li" title="T_ROB1"> <a href="tasks/T_ROB1" rel="self"></a> <span class="name">T_ROB1</span> <span class="type">normal</span><span class="taskstate">initiated</span><span class="excstate">started</span> <span class="active">On</span><span class="motiontask">TRUE</span></li></ul>';
var modulesBody = '<ul><li class="rap-module-info-li" title="T_ROB1/BASE"><span class="name">BASE</span><span class="type">SysMod</span></li><li class="rap-module-info-li" title="T_ROB1/MainModule"><span class="name">MainModule</span><span class="type">ProgMod</span></li></ul>';

check('parseLiSpans: extracts one object per task li, only listed fields', function() {
    var tasks = parseLiSpans(tasksBody, 'rap-task-li', ['name', 'type', 'taskstate', 'excstate', 'active', 'motiontask']);
    assert.strictEqual(tasks.length, 2);
    assert.deepStrictEqual(tasks[0], { name: 'SC_CBC', type: 'semistatic', taskstate: 'initiated', excstate: 'started' });
    assert.deepStrictEqual(tasks[1], { name: 'T_ROB1', type: 'normal', taskstate: 'initiated', excstate: 'started', active: 'On', motiontask: 'TRUE' });
});
check('parseLiSpans: extracts modules with a different li class/field set', function() {
    var modules = parseLiSpans(modulesBody, 'rap-module-info-li', ['name', 'type']);
    assert.deepStrictEqual(modules, [{ name: 'BASE', type: 'SysMod' }, { name: 'MainModule', type: 'ProgMod' }]);
});
check('parseLiSpans: returns empty array when no matching li blocks', function() {
    assert.deepStrictEqual(parseLiSpans('<ul></ul>', 'rap-task-li', ['name']), []);
});

// ── gofa-robot: atomic points.json writes ───────────────────────────────────
check('atomicWriteFileSync: writes file with given contents', function() {
    var f = path.join(tmpDir, 'atomic-a.json');
    atomicWriteFileSync(f, '{"x":1}');
    assert.strictEqual(fs.readFileSync(f, 'utf8'), '{"x":1}');
});
check('atomicWriteFileSync: overwrites existing file cleanly', function() {
    var f = path.join(tmpDir, 'atomic-b.json');
    fs.writeFileSync(f, 'old');
    atomicWriteFileSync(f, 'new');
    assert.strictEqual(fs.readFileSync(f, 'utf8'), 'new');
});
check('atomicWriteFileSync: leaves no leftover temp files', function() {
    var f = path.join(tmpDir, 'atomic-c.json');
    atomicWriteFileSync(f, 'data');
    var leftovers = fs.readdirSync(tmpDir).filter(function(n) { return n.indexOf('.tmp') >= 0; });
    assert.deepStrictEqual(leftovers, []);
});
check('fileMtimeMs: returns null for a missing file', function() {
    assert.strictEqual(fileMtimeMs(path.join(tmpDir, 'nope.json')), null);
});
check('fileMtimeMs: returns a number for an existing file', function() {
    var f = path.join(tmpDir, 'atomic-d.json');
    fs.writeFileSync(f, 'x');
    assert.strictEqual(typeof fileMtimeMs(f), 'number');
});

// ── gofa-robot: point management ────────────────────────────────────────────
function makeRobotNode(pointsFile) {
    var Ctor = loadNodeType('./nodes/gofa-robot');
    return new Ctor({ pointsFile: pointsFile });
}

check('gofa-robot: addPoint auto-names sequential points', function() {
    var node = makeRobotNode(path.join(tmpDir, 'points-1.json'));
    var p1 = node.addPoint('', { x: 1 });
    var p2 = node.addPoint('', { x: 2 });
    assert.strictEqual(p1.name, 'Point 1');
    assert.strictEqual(p2.name, 'Point 2');
});
check('gofa-robot: addPoint rejects duplicate names', function() {
    var node = makeRobotNode(path.join(tmpDir, 'points-2.json'));
    node.addPoint('pick1', { x: 1 });
    var res = node.addPoint('pick1', { x: 2 });
    assert.ok(res.error);
});
check('gofa-robot: addPoint persists to disk', function() {
    var f = path.join(tmpDir, 'points-3.json');
    var node = makeRobotNode(f);
    node.addPoint('pick1', { x: 1 });
    var onDisk = JSON.parse(fs.readFileSync(f, 'utf8'));
    assert.strictEqual(onDisk.length, 1);
    assert.strictEqual(onDisk[0].name, 'pick1');
});
check('gofa-robot: deletePoint removes by id and persists', function() {
    var f = path.join(tmpDir, 'points-4.json');
    var node = makeRobotNode(f);
    var p = node.addPoint('pick1', { x: 1 });
    node.deletePoint(p.id);
    assert.strictEqual(node.getPoints().length, 0);
    var onDisk = JSON.parse(fs.readFileSync(f, 'utf8'));
    assert.strictEqual(onDisk.length, 0);
});
check('gofa-robot: findPoint matches by name or id, else null', function() {
    var node = makeRobotNode(path.join(tmpDir, 'points-5.json'));
    var p = node.addPoint('pick1', { x: 1 });
    assert.strictEqual(node.findPoint('pick1'), p);
    assert.strictEqual(node.findPoint(p.id), p);
    assert.strictEqual(node.findPoint('missing'), null);
});
check('gofa-robot: _savePoints warns when the file changed on disk since last read', function() {
    var f = path.join(tmpDir, 'points-6.json');
    var node = makeRobotNode(f);
    node.addPoint('pick1', { x: 1 }); // first save creates the file, records its mtime
    var later = new Date(Date.now() + 5000);
    fs.utimesSync(f, later, later); // simulate another process/config-node writing it
    node.warnings = [];
    node.addPoint('pick2', { x: 2 });
    assert.ok(node.warnings.some(function(w) { return w.indexOf('changed on disk') >= 0; }));
});

// ── gofa-upload-mod: SERVER_IP injection ────────────────────────────────────
var sampleMod = 'MODULE MainModule\n' +
                '    CONST string SERVER_IP   := "192.168.20.15";\n' +
                '    CONST num    SERVER_PORT := 1025;\n' +
                'ENDMODULE\n';

check('patchServerIp: replaces the quoted IP when the constant is present', function() {
    var res = patchServerIp(sampleMod, '10.0.0.5');
    assert.strictEqual(res.injected, true);
    assert.ok(res.text.indexOf('CONST string SERVER_IP   := "10.0.0.5";') >= 0);
});
check('patchServerIp: is case-insensitive on the CONST/SERVER_IP keywords', function() {
    var mod = 'const STRING server_ip := "1.2.3.4";';
    var res = patchServerIp(mod, '9.9.9.9');
    assert.strictEqual(res.injected, true);
    assert.ok(res.text.indexOf('"9.9.9.9"') >= 0);
});
check('patchServerIp: leaves the rest of the file untouched', function() {
    var res = patchServerIp(sampleMod, '10.0.0.5');
    assert.ok(res.text.indexOf('CONST num    SERVER_PORT := 1025;') >= 0);
    assert.ok(res.text.indexOf('MODULE MainModule') >= 0);
});
check('patchServerIp: no-ops when the constant is not present', function() {
    var mod = 'MODULE Other\nENDMODULE\n';
    var res = patchServerIp(mod, '10.0.0.5');
    assert.strictEqual(res.injected, false);
    assert.strictEqual(res.text, mod);
});

// ── gofa-asi-led ──────────────────────────────────────────────────────────────
var led = require('./nodes/gofa-asi-led');
var clamp          = led.clamp;
var PRESETS        = led.PRESETS;
var resolvePayload = led.resolvePayload;
var DEF = { r: 0, g: 0, b: 0, period: 0 };

// clamp
check('clamp: 128 stays 128', function() { assert.strictEqual(clamp(128), 128); });
check('clamp: -10 clamps to 0', function() { assert.strictEqual(clamp(-10), 0); });
check('clamp: 300 clamps to 255', function() { assert.strictEqual(clamp(300), 255); });
check('clamp: 1.7 rounds to 2', function() { assert.strictEqual(clamp(1.7), 2); });
check('clamp: NaN clamps to 0', function() { assert.strictEqual(clamp(NaN), 0); });

// PRESETS
check('PRESETS: off is all zeros', function() {
    assert.deepStrictEqual(PRESETS.off, { r: 0, g: 0, b: 0 });
});
check('PRESETS: red is R=255 only', function() {
    assert.deepStrictEqual(PRESETS.red, { r: 255, g: 0, b: 0 });
});
check('PRESETS: white is all 255', function() {
    assert.deepStrictEqual(PRESETS.white, { r: 255, g: 255, b: 255 });
});

// resolvePayload — null/undefined uses defaults
check('resolvePayload: null payload returns node defaults', function() {
    var d = { r: 10, g: 20, b: 30, period: 5 };
    var res = resolvePayload(d, null);
    assert.deepStrictEqual(res, { r: 10, g: 20, b: 30, period: 5 });
});

// resolvePayload — bare string preset
check('resolvePayload: "red" string sets red preset', function() {
    var res = resolvePayload(DEF, 'red');
    assert.deepStrictEqual(res, { r: 255, g: 0, b: 0, period: 0 });
});
check('resolvePayload: "RED" string is case-insensitive', function() {
    var res = resolvePayload(DEF, 'RED');
    assert.deepStrictEqual(res, { r: 255, g: 0, b: 0, period: 0 });
});
check('resolvePayload: unknown color string returns error', function() {
    var res = resolvePayload(DEF, 'purple');
    assert.ok(res.error, 'should have error property');
});

// resolvePayload — bare non-zero number (inject timestamp) uses defaults
check('resolvePayload: timestamp number uses node defaults', function() {
    var d = { r: 10, g: 20, b: 30, period: 5 };
    var res = resolvePayload(d, Date.now());
    assert.deepStrictEqual(res, { r: 10, g: 20, b: 30, period: 5 });
});

// resolvePayload — false / 0 turns off
check('resolvePayload: false turns off and resets period', function() {
    var res = resolvePayload({ r: 255, g: 255, b: 255, period: 10 }, false);
    assert.deepStrictEqual(res, { r: 0, g: 0, b: 0, period: 0 });
});
check('resolvePayload: 0 turns off', function() {
    var res = resolvePayload(DEF, 0);
    assert.deepStrictEqual(res, { r: 0, g: 0, b: 0, period: 0 });
});

// resolvePayload — object with color name
check('resolvePayload: { color: "green" } sets green preset', function() {
    var res = resolvePayload(DEF, { color: 'green' });
    assert.deepStrictEqual(res, { r: 0, g: 255, b: 0, period: 0 });
});
check('resolvePayload: { color: "green" } unknown returns error', function() {
    var res = resolvePayload(DEF, { color: 'rainbow' });
    assert.ok(res.error);
});

// resolvePayload — explicit r/g/b object
check('resolvePayload: { r, g, b } sets custom color', function() {
    var res = resolvePayload(DEF, { r: 100, g: 150, b: 200 });
    assert.deepStrictEqual(res, { r: 100, g: 150, b: 200, period: 0 });
});
check('resolvePayload: r/g/b values are clamped', function() {
    var res = resolvePayload(DEF, { r: 300, g: -5, b: 128 });
    assert.deepStrictEqual(res, { r: 255, g: 0, b: 128, period: 0 });
});

// resolvePayload — period
check('resolvePayload: { color, period } sets preset + blink period', function() {
    var res = resolvePayload(DEF, { color: 'blue', period: 50 });
    assert.deepStrictEqual(res, { r: 0, g: 0, b: 255, period: 50 });
});
check('resolvePayload: period is floored to integer', function() {
    var res = resolvePayload(DEF, { r: 0, g: 0, b: 0, period: 33.9 });
    assert.strictEqual(res.period, 34);
});
check('resolvePayload: negative period clamps to 0', function() {
    var res = resolvePayload(DEF, { r: 0, g: 0, b: 0, period: -10 });
    assert.strictEqual(res.period, 0);
});

// resolvePayload — r/g/b override after preset
check('resolvePayload: color preset + r override blends correctly', function() {
    var res = resolvePayload(DEF, { color: 'red', g: 128 });
    assert.deepStrictEqual(res, { r: 255, g: 128, b: 0, period: 0 });
});

// ── async node tests (drive the real 'input' handlers) ──────────────────────
(async function() {

// gofa-points-import ─────────────────────────────────────────────────────────
await checkAsync('gofa-points-import: array payload replaces points', async function() {
    var mockRobot = { _points: [{ id: 'old', name: 'old' }], _savePoints: function() { this._saved = true; } };
    var node = new (loadNodeType('./nodes/gofa-points-import', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    var msg = { payload: [{ id: 'p1', name: 'p1', target: {} }] };
    await runInput(node, msg);
    assert.strictEqual(mockRobot._points.length, 1);
    assert.strictEqual(mockRobot._points[0].name, 'p1');
    assert.ok(mockRobot._saved);
    assert.deepStrictEqual(msg.payload, { ok: true, count: 1, loadedFrom: null });
});
await checkAsync('gofa-points-import: {points:[...]} wrapper is unwrapped', async function() {
    var mockRobot = { _points: [], _savePoints: function() {} };
    var node = new (loadNodeType('./nodes/gofa-points-import', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    await runInput(node, { payload: { points: [{ id: 'p1', name: 'p1' }] } });
    assert.strictEqual(mockRobot._points.length, 1);
});
await checkAsync('gofa-points-import: loads from a file path in msg.payload', async function() {
    var f = path.join(tmpDir, 'import-1.json');
    fs.writeFileSync(f, JSON.stringify([{ id: 'p1', name: 'p1' }]));
    var mockRobot = { _points: [], _savePoints: function() {} };
    var node = new (loadNodeType('./nodes/gofa-points-import', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    var msg = { payload: f };
    await runInput(node, msg);
    assert.strictEqual(mockRobot._points.length, 1);
    assert.strictEqual(msg.payload.loadedFrom, f);
});
await checkAsync('gofa-points-import: missing file reports an error', async function() {
    var mockRobot = { _points: [], _savePoints: function() {} };
    var node = new (loadNodeType('./nodes/gofa-points-import', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    var err = await runInput(node, { payload: path.join(tmpDir, 'missing.json') });
    assert.ok(err);
    assert.ok(node.errors.length > 0);
});
await checkAsync('gofa-points-import: missing robot config reports an error', async function() {
    var node = new (loadNodeType('./nodes/gofa-points-import', { nodesById: {} }))({ robot: 'nope' });
    await runInput(node, { payload: [] });
    assert.ok(node.errors.length > 0);
});

// gofa-points-export ─────────────────────────────────────────────────────────
await checkAsync('gofa-points-export: no savePath just outputs the points', async function() {
    var mockRobot = { getPoints: function() { return [{ id: 'p1', name: 'p1' }]; } };
    var node = new (loadNodeType('./nodes/gofa-points-export', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    var msg = { payload: null };
    await runInput(node, msg);
    assert.deepStrictEqual(msg.payload.points, [{ id: 'p1', name: 'p1' }]);
    assert.strictEqual(msg.payload.savedTo, undefined);
});
await checkAsync('gofa-points-export: savePath writes the file to disk', async function() {
    var f = path.join(tmpDir, 'export-1.json');
    var mockRobot = { getPoints: function() { return [{ id: 'p1', name: 'p1' }]; } };
    var node = new (loadNodeType('./nodes/gofa-points-export', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    var msg = { payload: f };
    await runInput(node, msg);
    assert.strictEqual(msg.payload.savedTo, f);
    assert.strictEqual(JSON.parse(fs.readFileSync(f, 'utf8')).length, 1);
});
await checkAsync('gofa-points-export: write failure reports an error', async function() {
    var mockRobot = { getPoints: function() { return []; } };
    var node = new (loadNodeType('./nodes/gofa-points-export', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    var badPath = path.join(tmpDir, 'nope-dir', 'x.json');
    var err = await runInput(node, { payload: badPath });
    assert.ok(err);
    assert.ok(node.errors.length > 0);
});

// gofa-robot: remote (on-robot) point management ────────────────────────────
// Mocks requestRaw/rwsPut directly on a real gofa-robot instance — these are
// the only two methods remoteGetPoints/remoteAddPoint/etc actually call, so
// this exercises the real remote* method bodies, not a reimplementation.
function makeRemoteRobotNode(fileState) {
    var node = makeRobotNode(path.join(tmpDir, 'unused-remote-points.json'));
    var stored = fileState.exists ? JSON.stringify(fileState.points || []) : null;
    node.requestRaw = function(method) {
        if (method !== 'GET') return Promise.reject(new Error('unexpected requestRaw ' + method));
        if (stored === null) return Promise.resolve({ statusCode: 404, headers: {}, body: Buffer.from('') });
        return Promise.resolve({ statusCode: 200, headers: {}, body: Buffer.from(stored) });
    };
    node.rwsPut = function(path, body) { stored = body; return Promise.resolve(''); };
    node._getStored = function() { return stored; };
    return node;
}

await checkAsync('gofa-robot: remoteGetPoints returns [] when the file does not exist (404)', async function() {
    var node = makeRemoteRobotNode({ exists: false });
    assert.deepStrictEqual(await node.remoteGetPoints(), []);
});
await checkAsync('gofa-robot: remoteAddPoint auto-names and persists via rwsPut', async function() {
    var node = makeRemoteRobotNode({ exists: false });
    var p1 = await node.remoteAddPoint('', { x: 1 });
    assert.strictEqual(p1.name, 'Point 1');
    var stored = JSON.parse(node._getStored());
    assert.strictEqual(stored.length, 1);
    assert.strictEqual(stored[0].name, 'Point 1');
});
await checkAsync('gofa-robot: remoteAddPoint rejects duplicate names', async function() {
    var node = makeRemoteRobotNode({ exists: true, points: [{ id: 'p1', name: 'pick1', target: {} }] });
    var res = await node.remoteAddPoint('pick1', { x: 2 });
    assert.ok(res.error);
});
await checkAsync('gofa-robot: remoteDeletePoint removes by name and persists', async function() {
    var node = makeRemoteRobotNode({ exists: true, points: [{ id: 'p1', name: 'pick1', target: {} }] });
    var deleted = await node.remoteDeletePoint('pick1');
    assert.strictEqual(deleted.name, 'pick1');
    assert.deepStrictEqual(JSON.parse(node._getStored()), []);
});
await checkAsync('gofa-robot: remoteDeletePoint returns null when not found', async function() {
    var node = makeRemoteRobotNode({ exists: true, points: [] });
    assert.strictEqual(await node.remoteDeletePoint('missing'), null);
});
await checkAsync('gofa-robot: remoteFindPoint matches by name or id, else null', async function() {
    var node = makeRemoteRobotNode({ exists: true, points: [{ id: 'p1', name: 'pick1', target: { x: 1 } }] });
    assert.strictEqual((await node.remoteFindPoint('pick1')).name, 'pick1');
    assert.strictEqual((await node.remoteFindPoint('p1')).name, 'pick1');
    assert.strictEqual(await node.remoteFindPoint('nope'), null);
});

// gofa-go-point ──────────────────────────────────────────────────────────────
function makeGoPointRobot(pt) {
    var calls = [];
    return {
        findPoint: function() { return pt; },
        gotoToken: function(target, moveType) { calls.push(moveType); return 'GOTOJ' + JSON.stringify(target); },
        socketSend: function(token) { return Promise.resolve('OK:' + token); },
        _calls: calls
    };
}
await checkAsync('gofa-go-point: uses the configured move type by default', async function() {
    var mockRobot = makeGoPointRobot({ name: 'pick1', target: {} });
    var node = new (loadNodeType('./nodes/gofa-go-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', moveType: 'L' });
    var msg = { payload: {} };
    await runInput(node, msg);
    assert.deepStrictEqual(mockRobot._calls, ['L']);
    assert.strictEqual(msg.payload.moveType, 'L');
});
await checkAsync('gofa-go-point: msg.payload.moveType overrides the configured value', async function() {
    var mockRobot = makeGoPointRobot({ name: 'pick1', target: {} });
    var node = new (loadNodeType('./nodes/gofa-go-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', moveType: 'J' });
    var msg = { payload: { moveType: 'L' } };
    await runInput(node, msg);
    assert.deepStrictEqual(mockRobot._calls, ['L']);
});
await checkAsync('gofa-go-point: invalid msg.payload.moveType falls back to configured value', async function() {
    var mockRobot = makeGoPointRobot({ name: 'pick1', target: {} });
    var node = new (loadNodeType('./nodes/gofa-go-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', moveType: 'L' });
    var msg = { payload: { moveType: 'sideways' } };
    await runInput(node, msg);
    assert.deepStrictEqual(mockRobot._calls, ['L']);
});
await checkAsync('gofa-go-point: storage "remote" looks the point up via remoteFindPoint', async function() {
    var calls = [];
    var mockRobot = {
        findPoint: function() { throw new Error('must not use local findPoint in remote mode'); },
        remoteFindPoint: function(name) { calls.push(name); return Promise.resolve({ name: 'pick1', target: {} }); },
        gotoToken: function() { return 'GOTOJ{}'; },
        socketSend: function(token) { return Promise.resolve('OK:' + token); }
    };
    var node = new (loadNodeType('./nodes/gofa-go-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', storage: 'remote', pointName: 'pick1' });
    var msg = {};
    await runInput(node, msg);
    assert.deepStrictEqual(calls, ['pick1']);
    assert.strictEqual(msg.payload.ok, true);
});

// gofa-save-point ────────────────────────────────────────────────────────────
var samplePoseBody = '<span class="x">1</span><span class="y">2</span><span class="z">3</span>' +
    '<span class="q1">0</span><span class="q2">0</span><span class="q3">0</span><span class="q4">1</span>' +
    '<span class="cf1">0</span><span class="cf4">0</span><span class="cf6">0</span><span class="cfx">0</span>';
await checkAsync('gofa-save-point: storage "local" (default) uses addPoint/getPoints', async function() {
    var calls = [];
    var mockRobot = {
        rwsGet: function() { return Promise.resolve(samplePoseBody); },
        parseXhtml: parseXhtml,
        addPoint: function(name, target) { calls.push(['add', name, target]); return { id: 'p1', name: 'pick1', target: target }; },
        getPoints: function() { return [{ id: 'p1', name: 'pick1' }]; }
    };
    var node = new (loadNodeType('./nodes/gofa-save-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', pointName: 'pick1' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(msg.payload.point.name, 'pick1');
    assert.strictEqual(calls[0][0], 'add');
});
await checkAsync('gofa-save-point: storage "remote" uses remoteAddPoint/remoteGetPoints', async function() {
    var calls = [];
    var mockRobot = {
        rwsGet: function() { return Promise.resolve(samplePoseBody); },
        parseXhtml: parseXhtml,
        addPoint: function() { throw new Error('must not use local addPoint in remote mode'); },
        remoteAddPoint: function(name, target) { calls.push(['add', name, target]); return Promise.resolve({ id: 'p1', name: 'pick1', target: target }); },
        remoteGetPoints: function() { return Promise.resolve([{ id: 'p1', name: 'pick1' }]); }
    };
    var node = new (loadNodeType('./nodes/gofa-save-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', storage: 'remote', pointName: 'pick1' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(msg.payload.point.name, 'pick1');
    assert.strictEqual(msg.payload.points.length, 1);
    assert.strictEqual(calls[0][0], 'add');
});
await checkAsync('gofa-save-point: storage "remote" surfaces a duplicate-name error', async function() {
    var mockRobot = {
        rwsGet: function() { return Promise.resolve(samplePoseBody); },
        parseXhtml: parseXhtml,
        remoteAddPoint: function() { return Promise.resolve({ error: 'A point named "pick1" already exists' }); }
    };
    var node = new (loadNodeType('./nodes/gofa-save-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', storage: 'remote', pointName: 'pick1' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, false);
    assert.ok(msg.payload.error.indexOf('already exists') >= 0);
});

// gofa-delete-point ──────────────────────────────────────────────────────────
await checkAsync('gofa-delete-point: storage "local" (default) uses findPoint/deletePoint', async function() {
    var deletedId;
    var mockRobot = {
        findPoint: function(name) { return name === 'pick1' ? { id: 'p1', name: 'pick1' } : null; },
        deletePoint: function(id) { deletedId = id; },
        getPoints: function() { return []; }
    };
    var node = new (loadNodeType('./nodes/gofa-delete-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', pointName: 'pick1' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(deletedId, 'p1');
});
await checkAsync('gofa-delete-point: storage "remote" uses remoteFindPoint/remoteDeletePoint', async function() {
    var deletedId;
    var mockRobot = {
        findPoint: function() { throw new Error('must not use local findPoint in remote mode'); },
        remoteFindPoint: function(name) { return Promise.resolve(name === 'pick1' ? { id: 'p1', name: 'pick1' } : null); },
        remoteDeletePoint: function(id) { deletedId = id; return Promise.resolve({ id: id, name: 'pick1' }); },
        remoteGetPoints: function() { return Promise.resolve([]); }
    };
    var node = new (loadNodeType('./nodes/gofa-delete-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', storage: 'remote', pointName: 'pick1' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(deletedId, 'p1');
    assert.deepStrictEqual(msg.payload.points, []);
});
await checkAsync('gofa-delete-point: reports "not found" without touching remoteDeletePoint', async function() {
    var mockRobot = {
        remoteFindPoint: function() { return Promise.resolve(null); },
        remoteDeletePoint: function() { throw new Error('must not delete when point was not found'); }
    };
    var node = new (loadNodeType('./nodes/gofa-delete-point', { nodesById: { r1: mockRobot } }))({ robot: 'r1', storage: 'remote', pointName: 'missing' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, false);
    assert.ok(msg.payload.error.indexOf('not found') >= 0);
});

// gofa-point-list ────────────────────────────────────────────────────────────
await checkAsync('gofa-point-list: storage "local" (default) uses getPoints', async function() {
    var mockRobot = { getPoints: function() { return [{ id: 'p1', name: 'pick1' }]; } };
    var node = new (loadNodeType('./nodes/gofa-point-list', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.length, 1);
});
await checkAsync('gofa-point-list: storage "remote" uses remoteGetPoints', async function() {
    var mockRobot = {
        getPoints: function() { throw new Error('must not use local getPoints in remote mode'); },
        remoteGetPoints: function() { return Promise.resolve([{ id: 'p1', name: 'pick1' }, { id: 'p2', name: 'pick2' }]); }
    };
    var node = new (loadNodeType('./nodes/gofa-point-list', { nodesById: { r1: mockRobot } }))({ robot: 'r1', storage: 'remote' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.length, 2);
});

// gofa-sequencer + gofa-stop-seq ─────────────────────────────────────────────
function makeSeqRobot(pointMap) {
    var calls = [];
    return {
        _seqStop: false, _seqRunning: false, _calls: calls,
        findPoint: function(name) { return pointMap[name] || null; },
        getPoints: function() { return Object.keys(pointMap).map(function(k) { return pointMap[k]; }); },
        gotoToken: function(target, moveType) { calls.push(moveType); return 'GOTO' + moveType + JSON.stringify(target); },
        socketSend: function(token) { return Promise.resolve('OK:' + token); }
    };
}
function stepMsgs(node) { return node.sent.filter(function(m) { return m[0]; }).map(function(m) { return m[0]; }); }
function endMsg(node)   { var m = node.sent.filter(function(m) { return m[1]; })[0]; return m && m[1]; }

await checkAsync('gofa-sequencer: runs steps in order and reports done', async function() {
    var points = { pick1: { name: 'pick1', target: { x: 1 } }, pick2: { name: 'pick2', target: { x: 2 } } };
    var node = new (loadNodeType('./nodes/gofa-sequencer', { nodesById: { r1: makeSeqRobot(points) } }))({ robot: 'r1', dwell: 0 });
    var err = await runInput(node, { payload: { steps: [{ name: 'pick1' }, { name: 'pick2' }] } });
    assert.strictEqual(err, undefined);
    var steps = stepMsgs(node);
    assert.strictEqual(steps.length, 2);
    assert.strictEqual(steps[0].payload.name, 'pick1');
    assert.strictEqual(steps[1].payload.name, 'pick2');
    assert.deepStrictEqual(endMsg(node).payload, { done: true, loops: 1 });
});
await checkAsync('gofa-sequencer: errors when no valid points are found', async function() {
    var node = new (loadNodeType('./nodes/gofa-sequencer', { nodesById: { r1: makeSeqRobot({}) } }))({ robot: 'r1', dwell: 0 });
    await runInput(node, { payload: { steps: [{ name: 'missing' }] } });
    assert.ok(node.errors.length > 0);
    assert.strictEqual(node.sent.length, 0);
});
await checkAsync('gofa-sequencer: pingpong mirrors the sequence', async function() {
    var points = { a: { name: 'a', target: {} }, b: { name: 'b', target: {} }, c: { name: 'c', target: {} } };
    var node = new (loadNodeType('./nodes/gofa-sequencer', { nodesById: { r1: makeSeqRobot(points) } }))({ robot: 'r1', dwell: 0, pingpong: true });
    await runInput(node, { payload: { steps: [{ name: 'a' }, { name: 'b' }, { name: 'c' }] } });
    assert.deepStrictEqual(stepMsgs(node).map(function(m) { return m.payload.name; }), ['a', 'b', 'c', 'b', 'a']);
});
await checkAsync('gofa-sequencer: loop respects count', async function() {
    var points = { a: { name: 'a', target: {} } };
    var node = new (loadNodeType('./nodes/gofa-sequencer', { nodesById: { r1: makeSeqRobot(points) } }))({ robot: 'r1', dwell: 0, loop: true, count: 2 });
    await runInput(node, { payload: { steps: [{ name: 'a' }] } });
    assert.strictEqual(stepMsgs(node).length, 2);
    assert.deepStrictEqual(endMsg(node).payload, { done: true, loops: 2 });
});
await checkAsync('gofa-sequencer: uses the node-level default move type', async function() {
    var points = { a: { name: 'a', target: {} }, b: { name: 'b', target: {} } };
    var mockRobot = makeSeqRobot(points);
    var node = new (loadNodeType('./nodes/gofa-sequencer', { nodesById: { r1: mockRobot } }))({ robot: 'r1', dwell: 0, moveType: 'L' });
    await runInput(node, { payload: { steps: [{ name: 'a' }, { name: 'b' }] } });
    assert.deepStrictEqual(mockRobot._calls, ['L', 'L']);
    assert.strictEqual(stepMsgs(node)[0].payload.moveType, 'L');
});
await checkAsync('gofa-sequencer: a per-step move type overrides the default', async function() {
    var points = { a: { name: 'a', target: {} }, b: { name: 'b', target: {} } };
    var mockRobot = makeSeqRobot(points);
    var node = new (loadNodeType('./nodes/gofa-sequencer', { nodesById: { r1: mockRobot } }))({ robot: 'r1', dwell: 0, moveType: 'J' });
    await runInput(node, { payload: { steps: [{ name: 'a', moveType: 'L' }, { name: 'b' }] } });
    assert.deepStrictEqual(mockRobot._calls, ['L', 'J']);
});
await checkAsync('gofa-sequencer: stops early once _seqStop is set', async function() {
    var points = { a: { name: 'a', target: {} }, b: { name: 'b', target: {} }, c: { name: 'c', target: {} } };
    var mockRobot = makeSeqRobot(points);
    var node = new (loadNodeType('./nodes/gofa-sequencer', { nodesById: { r1: mockRobot } }))({ robot: 'r1', dwell: 5 });
    var runPromise = runInput(node, { payload: { steps: [{ name: 'a' }, { name: 'b' }, { name: 'c' }] } });
    await Promise.resolve(); await Promise.resolve(); // let step 1's socketSend().then() fire
    mockRobot._seqStop = true;                          // before the dwell timer for step 2 elapses
    await runPromise;
    assert.strictEqual(stepMsgs(node).length, 1);
    assert.strictEqual(endMsg(node).payload.stopped, true);
});
await checkAsync('gofa-sequencer: storage "remote" fetches the point list once via remoteGetPoints, not getPoints', async function() {
    var getPointsCalls = 0, remoteGetPointsCalls = 0;
    var mockRobot = {
        _seqStop: false, _seqRunning: false,
        getPoints: function() { getPointsCalls++; return []; },
        remoteGetPoints: function() { remoteGetPointsCalls++; return Promise.resolve([{ name: 'a', target: {} }, { name: 'b', target: {} }]); },
        gotoToken: function(target) { return 'GOTOJ' + JSON.stringify(target); },
        socketSend: function(token) { return Promise.resolve('OK:' + token); }
    };
    var node = new (loadNodeType('./nodes/gofa-sequencer', { nodesById: { r1: mockRobot } }))({ robot: 'r1', storage: 'remote', dwell: 0 });
    await runInput(node, { payload: { steps: [{ name: 'a' }, { name: 'b' }] } });
    assert.strictEqual(remoteGetPointsCalls, 1, 'must fetch the remote list exactly once for the whole sequence');
    assert.strictEqual(getPointsCalls, 0, 'must not touch local getPoints in remote mode');
    assert.strictEqual(stepMsgs(node).length, 2);
    assert.deepStrictEqual(endMsg(node).payload, { done: true, loops: 1 });
});
await checkAsync('gofa-stop-seq: sets the stop flag and sends STOP', async function() {
    var sentCmds = [];
    var mockRobot = { _seqStop: false, socketSend: function(cmd) { sentCmds.push(cmd); return Promise.resolve('OK:STOP'); } };
    var node = new (loadNodeType('./nodes/gofa-stop-seq', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    await runInput(node, {});
    assert.strictEqual(mockRobot._seqStop, true);
    assert.deepStrictEqual(sentCmds, ['STOP']);
});

// gofa-upload-mod: node-level tests go through r.rwsPut() (the public API),
// not private robot internals like r._getSession/r._cookie — a mock robot only
// exposing what the real GoFaRobotNode exposes is what would have caught the
// "r._getSession is not a function" regression from a gofa-robot.js refactor
// that moved session/cookie state into a private createRobotClient() closure.
await checkAsync('gofa-upload-mod: uploads via r.rwsPut with text/plain content type', async function() {
    var calls = [];
    var mockRobot = {
        ip: '10.0.0.9',
        rwsPut: function(p, b, contentType) {
            calls.push({ path: p, body: b, contentType: contentType });
            return Promise.resolve('');
        }
    };
    var tmpFile = path.join(tmpDir, 'MainModule.mod');
    fs.writeFileSync(tmpFile, sampleMod);
    var node = new (loadNodeType('./nodes/gofa-upload-mod', { nodesById: { r1: mockRobot } }))({
        robot: 'r1', localPath: tmpFile, remotePath: '$HOME/Programs/MainModule.mod'
    });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(calls.length, 1);
    assert.strictEqual(calls[0].path, '/fileservice/$HOME/Programs/MainModule.mod');
    assert.strictEqual(calls[0].contentType, 'text/plain;v=2.0');
    assert.ok(calls[0].body.toString().indexOf('"10.0.0.9"') >= 0, 'SERVER_IP should be patched to the robot ip');
});
await checkAsync('gofa-upload-mod: reports failure when rwsPut rejects', async function() {
    var mockRobot = { ip: '10.0.0.9', rwsPut: function() { return Promise.reject(new Error('HTTP 401 — auth failed')); } };
    var tmpFile = path.join(tmpDir, 'Other.mod');
    fs.writeFileSync(tmpFile, 'MODULE Other\nENDMODULE\n');
    var node = new (loadNodeType('./nodes/gofa-upload-mod', { nodesById: { r1: mockRobot } }))({ robot: 'r1', localPath: tmpFile });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, false);
    assert.ok(msg.payload.error.indexOf('401') >= 0);
});

// gofa-rapid-exec ────────────────────────────────────────────────────────────
function makeRapidExecRobot(opts) {
    opts = opts || {};
    var calls = [];
    var execSeq = (opts.execstateSeq || ['running']).slice();
    return {
        calls: calls,
        rwsGet: function(p) {
            calls.push(['GET', p]);
            if (p === '/rw/panel/ctrl-state') return Promise.resolve('CTRLSTATE:' + (opts.ctrlstate || 'motoron'));
            if (p === '/rw/rapid/execution') return Promise.resolve('EXECSTATE:' + (execSeq.length > 1 ? execSeq.shift() : execSeq[0]));
            return Promise.reject(new Error('unexpected GET ' + p));
        },
        rwsPost: function(p, b) {
            calls.push(['POST', p, b]);
            if (opts.postError) return Promise.reject(opts.postError);
            return Promise.resolve('');
        },
        rwsPostHal: function(p, b) {
            calls.push(['POST-HAL', p, b]);
            if (opts.postError) return Promise.reject(opts.postError);
            return Promise.resolve(opts.loadmodResponse || '{"state":[{"name":"MainModule"}]}');
        },
        parseXhtml: function(body) {
            var m = /:(.*)$/.exec(body);
            return m ? m[1] : null;
        },
        withMastership: function(fn) { return fn(); }
    };
}
await checkAsync('gofa-rapid-exec: start refuses up front when motors are off (no POST sent)', async function() {
    var mockRobot = makeRapidExecRobot({ ctrlstate: 'motoroff' });
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({ robot: 'r1', action: 'start' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, false);
    assert.ok(msg.payload.error.indexOf('motors are motoroff') >= 0, msg.payload.error);
    assert.strictEqual(msg.payload.ctrlstate, 'motoroff');
    assert.ok(!mockRobot.calls.some(function(c) { return c[0] === 'POST'; }), 'must not POST start when motors are off');
});
await checkAsync('gofa-rapid-exec: start succeeds when motors are on and execstate confirms running', async function() {
    var mockRobot = makeRapidExecRobot({ ctrlstate: 'motoron', execstateSeq: ['running'] });
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({ robot: 'r1', action: 'start' });
    var msg = {};
    await runInput(node, msg);
    assert.deepStrictEqual(msg.payload, { ok: true, action: 'start' });
    assert.ok(mockRobot.calls.some(function(c) { return c[0] === 'POST' && c[1] === '/rw/rapid/execution/start'; }));
});
await checkAsync('gofa-rapid-exec: start reports failure when execstate never reaches running (silent RWS rejection)', async function() {
    var mockRobot = makeRapidExecRobot({ ctrlstate: 'motoron', execstateSeq: ['stopped'] });
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({ robot: 'r1', action: 'start' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, false);
    assert.ok(msg.payload.error.indexOf('did not start') >= 0, msg.payload.error);
    assert.strictEqual(msg.payload.execstate, 'stopped');
});
await checkAsync('gofa-rapid-exec: stop does not check ctrl-state', async function() {
    var mockRobot = makeRapidExecRobot({ ctrlstate: 'motoroff' });
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({ robot: 'r1', action: 'stop' });
    var msg = {};
    await runInput(node, msg);
    assert.deepStrictEqual(msg.payload, { ok: true, action: 'stop' });
    assert.ok(!mockRobot.calls.some(function(c) { return c[1] === '/rw/panel/ctrl-state'; }));
});
await checkAsync('gofa-rapid-exec: resetpp acquires mastership and does not check ctrl-state', async function() {
    var mockRobot = makeRapidExecRobot({ ctrlstate: 'motoroff' });
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({ robot: 'r1', action: 'resetpp' });
    var msg = {};
    await runInput(node, msg);
    assert.deepStrictEqual(msg.payload, { ok: true, action: 'resetpp' });
});
await checkAsync('gofa-rapid-exec: loadmod acquires mastership, uses hal+json, and parses the loaded module name', async function() {
    var mockRobot = makeRapidExecRobot({ ctrlstate: 'motoroff' });
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({
        robot: 'r1', action: 'loadmod', task: 'T_ROB1', modulePath: '$HOME/Programs/MainModule.mod', replace: true
    });
    var msg = {};
    await runInput(node, msg);
    assert.deepStrictEqual(msg.payload, {
        ok: true, action: 'loadmod', task: 'T_ROB1', modulePath: '$HOME/Programs/MainModule.mod', module: 'MainModule'
    });
    var call = mockRobot.calls.filter(function(c) { return c[0] === 'POST-HAL'; })[0];
    assert.ok(call, 'must call rwsPostHal, not rwsPost, for loadmod');
    assert.strictEqual(call[1], '/rw/rapid/tasks/T_ROB1/loadmod');
    assert.ok(call[2].indexOf('modulepath=') >= 0 && call[2].indexOf('replace=true') >= 0, call[2]);
    assert.ok(!mockRobot.calls.some(function(c) { return c[1] === '/rw/panel/ctrl-state'; }), 'must not check ctrl-state for loadmod');
});
await checkAsync('gofa-rapid-exec: msg.payload can override task/modulePath/replace for loadmod', async function() {
    var mockRobot = makeRapidExecRobot();
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({ robot: 'r1', action: 'loadmod' });
    var msg = { payload: { action: 'loadmod', task: 'T_ROB2', modulePath: '$HOME/Programs/Other.mod', replace: false } };
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(msg.payload.task, 'T_ROB2');
    var call = mockRobot.calls.filter(function(c) { return c[0] === 'POST-HAL'; })[0];
    assert.strictEqual(call[1], '/rw/rapid/tasks/T_ROB2/loadmod');
    assert.ok(call[2].indexOf('Other.mod') >= 0 && call[2].indexOf('replace=false') >= 0, call[2]);
});
await checkAsync('gofa-rapid-exec: activate acquires mastership, uses hal+json, and reports task/module', async function() {
    var mockRobot = makeRapidExecRobot({ ctrlstate: 'motoroff' });
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({
        robot: 'r1', action: 'activate', task: 'T_ROB1', module: 'MainModule'
    });
    var msg = {};
    await runInput(node, msg);
    assert.deepStrictEqual(msg.payload, { ok: true, action: 'activate', task: 'T_ROB1', module: 'MainModule' });
    var call = mockRobot.calls.filter(function(c) { return c[0] === 'POST-HAL'; })[0];
    assert.ok(call, 'must call rwsPostHal, not rwsPost, for activate');
    assert.strictEqual(call[1], '/rw/rapid/tasks/T_ROB1/activate');
    assert.strictEqual(call[2], 'module=MainModule');
    assert.ok(!mockRobot.calls.some(function(c) { return c[1] === '/rw/panel/ctrl-state'; }), 'must not check ctrl-state for activate');
});
await checkAsync('gofa-rapid-exec: msg.payload can override task/module for activate', async function() {
    var mockRobot = makeRapidExecRobot();
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({ robot: 'r1', action: 'activate' });
    var msg = { payload: { action: 'activate', task: 'T_ROB2', module: 'OtherModule' } };
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(msg.payload.task, 'T_ROB2');
    assert.strictEqual(msg.payload.module, 'OtherModule');
    var call = mockRobot.calls.filter(function(c) { return c[0] === 'POST-HAL'; })[0];
    assert.strictEqual(call[1], '/rw/rapid/tasks/T_ROB2/activate');
    assert.strictEqual(call[2], 'module=OtherModule');
});
await checkAsync('gofa-rapid-exec: activate/loadmod give a clear hint on the "RAPID must be stopped" 403', async function() {
    // Confirmed live: RWS rejects activate/loadmod with this exact message while RAPID is running.
    var pgmStateError = new Error('HTTP 403 /rw/rapid/tasks/T_ROB1/activate — Operation not allowed for current PGM state (Started/Stopped/Ready)');
    var mockRobot = makeRapidExecRobot({ postError: pgmStateError });
    var node = new (loadNodeType('./nodes/gofa-rapid-exec', { nodesById: { r1: mockRobot } }))({ robot: 'r1', action: 'activate' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, false);
    assert.ok(msg.payload.error.indexOf('RAPID must be stopped for activate') >= 0, msg.payload.error);
});

// gofa-rapid-tasks ───────────────────────────────────────────────────────────
await checkAsync('gofa-rapid-tasks: reads tasks and the default task\'s modules', async function() {
    var calls = [];
    var mockRobot = {
        rwsGet: function(p) {
            calls.push(p);
            if (p === '/rw/rapid/tasks') return Promise.resolve(tasksBody);
            if (p === '/rw/rapid/tasks/T_ROB1/modules') return Promise.resolve(modulesBody);
            return Promise.reject(new Error('unexpected GET ' + p));
        }
    };
    var node = new (loadNodeType('./nodes/gofa-rapid-tasks', { nodesById: { r1: mockRobot } }))({ robot: 'r1', task: 'T_ROB1' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(msg.payload.tasks.length, 2);
    assert.strictEqual(msg.payload.task, 'T_ROB1');
    assert.deepStrictEqual(msg.payload.modules, [{ name: 'BASE', type: 'SysMod' }, { name: 'MainModule', type: 'ProgMod' }]);
    assert.deepStrictEqual(calls, ['/rw/rapid/tasks', '/rw/rapid/tasks/T_ROB1/modules']);
});
await checkAsync('gofa-rapid-tasks: msg.payload.task overrides which task\'s modules are fetched', async function() {
    var requestedModulePath;
    var mockRobot = {
        rwsGet: function(p) {
            if (p === '/rw/rapid/tasks') return Promise.resolve(tasksBody);
            requestedModulePath = p;
            return Promise.resolve('<ul></ul>');
        }
    };
    var node = new (loadNodeType('./nodes/gofa-rapid-tasks', { nodesById: { r1: mockRobot } }))({ robot: 'r1', task: 'T_ROB1' });
    var msg = { payload: { task: 'SC_CBC' } };
    await runInput(node, msg);
    assert.strictEqual(requestedModulePath, '/rw/rapid/tasks/SC_CBC/modules');
    assert.strictEqual(msg.payload.task, 'SC_CBC');
});
await checkAsync('gofa-rapid-tasks: reports failure on RWS error', async function() {
    var mockRobot = { rwsGet: function() { return Promise.reject(new Error('HTTP 500')); } };
    var node = new (loadNodeType('./nodes/gofa-rapid-tasks', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, false);
    assert.ok(msg.payload.error.indexOf('HTTP 500') >= 0);
});

// gofa-file-read / gofa-subscribe-io / gofa-subscribe-state ─────────────────
// These three go through robot.requestRaw()/robot.getCookie() (the public API)
// instead of the private robot._getSession/_cookie/_request fields that a
// gofa-robot.js refactor removed — mock robots below deliberately expose only
// the public methods, so a regression back to the private fields fails loudly
// with "... is not a function" instead of silently passing.
async function flush() { for (var i = 0; i < 6; i++) await Promise.resolve(); }

await checkAsync('gofa-file-read: reads a file via robot.requestRaw, not private robot internals', async function() {
    var calls = [];
    var mockRobot = {
        requestRaw: function(method, p, body, opts) {
            calls.push({ method: method, path: p, opts: opts });
            return Promise.resolve({ statusCode: 200, headers: {}, body: Buffer.from('MODULE Foo\nENDMODULE\n') });
        }
    };
    var node = new (loadNodeType('./nodes/gofa-file-read', { nodesById: { r1: mockRobot } }))(
        { robot: 'r1', remotePath: '$HOME/Programs/MainModule.mod', encoding: 'utf8' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(msg.payload.content, 'MODULE Foo\nENDMODULE\n');
    assert.strictEqual(calls.length, 1);
    assert.strictEqual(calls[0].method, 'GET');
    assert.strictEqual(calls[0].path, '/fileservice/$HOME/Programs/MainModule.mod');
});
await checkAsync('gofa-file-read: reports failure on a non-2xx status', async function() {
    var mockRobot = { requestRaw: function() { return Promise.resolve({ statusCode: 404, headers: {}, body: Buffer.from('') }); } };
    var node = new (loadNodeType('./nodes/gofa-file-read', { nodesById: { r1: mockRobot } }))({ robot: 'r1', remotePath: 'nope.mod' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, false);
    assert.ok(msg.payload.error.indexOf('404') >= 0);
});
await checkAsync('gofa-subscribe-io: subscribes via robot.requestRaw (not private robot internals), falls back to polling on HTTP 400', async function() {
    var calls = [];
    var mockRobot = {
        requestRaw: function(method, p, body, opts) {
            calls.push({ method: method, path: p, body: body });
            return Promise.resolve({ statusCode: 400, headers: {}, body: Buffer.from('') });
        },
        getCookie: function() { return Promise.resolve('cookie=abc'); },
        rwsGet: function() { return Promise.resolve('<span class="lvalue">1</span>'); }
    };
    var node = new (loadNodeType('./nodes/gofa-subscribe-io', { nodesById: { r1: mockRobot } }))({ robot: 'r1', signal: 'Asi1Button1' });
    var msg = {};
    await runInput(node, msg);
    await flush();
    assert.ok(calls.some(function(c) { return c.method === 'POST' && c.path === '/subscription'; }));
    assert.ok(node._pollTimer, 'must fall back to polling when the subscribe request itself fails with HTTP 400');
    clearInterval(node._pollTimer);
});
await checkAsync('gofa-subscribe-state: subscribes via robot.requestRaw (not private robot internals), reports error on HTTP 400', async function() {
    var calls = [];
    var mockRobot = {
        requestRaw: function(method, p, body, opts) {
            calls.push({ method: method, path: p, body: body });
            return Promise.resolve({ statusCode: 400, headers: {}, body: Buffer.from('') });
        },
        getCookie: function() { return Promise.resolve('cookie=abc'); }
    };
    var node = new (loadNodeType('./nodes/gofa-subscribe-state', { nodesById: { r1: mockRobot } }))({ robot: 'r1' });
    var msg = {};
    await runInput(node, msg);
    await flush();
    assert.ok(calls.some(function(c) { return c.method === 'POST' && c.path === '/subscription'; }));
    assert.ok(node.errors.length > 0, 'must report the subscribe failure');
});

// gofa-subscribe-var ─────────────────────────────────────────────────────────

await checkAsync('gofa-subscribe-var: reads via module-text only, never attempts the dead RWS symbol path', async function() {
    var calls = [];
    var mockRobot = {
        rwsGet: function(p) {
            calls.push(p);
            if (p === '/rw/rapid/tasks/T_ROB1/modules/MainModule/text') {
                return Promise.resolve('<span class="file-path">TEMP/MainModule.mod</span>');
            }
            if (p === '/fileservice/TEMP/MainModule.mod') {
                return Promise.resolve('PERS num nTestVar := 7;');
            }
            return Promise.reject(new Error('unexpected GET ' + p));
        },
        parseXhtml: parseXhtml
    };
    var node = new (loadNodeType('./nodes/gofa-subscribe-var', { nodesById: { r1: mockRobot } }))(
        { robot: 'r1', task: 'T_ROB1', module: 'MainModule', variable: 'nTestVar', interval: '100000' });
    await runInput(node, {}); // toggle on -> first poll fires immediately
    await flush();
    node._polling = false; if (node._timer) clearTimeout(node._timer); // stop before the next tick fires

    assert.ok(!calls.some(function(p) { return p.indexOf('/rw/rapid/symbol/data/') >= 0; }), 'must not attempt the dead RWS symbol endpoint');
    assert.strictEqual(node.sent.length, 1);
    assert.strictEqual(node.sent[0].payload.value, '7');
    assert.strictEqual(node.sent[0].payload.source, 'module-text');
    assert.strictEqual(node.sent[0].payload.stale, true, 'module-text reads must be flagged stale — confirmed live to return the compiled value, not the current one');
});
await checkAsync('gofa-subscribe-var: toggles off on the second input without sending another message', async function() {
    var mockRobot = {
        rwsGet: function(p) {
            if (p.indexOf('/text') >= 0) return Promise.resolve('<span class="file-path">TEMP/MainModule.mod</span>');
            return Promise.resolve('PERS num nTestVar := 1;');
        },
        parseXhtml: parseXhtml
    };
    var node = new (loadNodeType('./nodes/gofa-subscribe-var', { nodesById: { r1: mockRobot } }))(
        { robot: 'r1', task: 'T_ROB1', module: 'MainModule', variable: 'nTestVar', interval: '100000' });
    await runInput(node, {});
    await flush();
    assert.strictEqual(node.sent.length, 1);
    await runInput(node, {}); // toggle off
    assert.strictEqual(node._polling, false);
    await flush();
    assert.strictEqual(node.sent.length, 1, 'no further message after stopping');
});
await checkAsync('gofa-subscribe-var: reports an error status when the variable is not found', async function() {
    var mockRobot = {
        rwsGet: function(p) {
            if (p.indexOf('/text') >= 0) return Promise.resolve('<span class="file-path">TEMP/MainModule.mod</span>');
            return Promise.resolve('PERS num somethingElse := 1;');
        },
        parseXhtml: parseXhtml
    };
    var node = new (loadNodeType('./nodes/gofa-subscribe-var', { nodesById: { r1: mockRobot } }))(
        { robot: 'r1', task: 'T_ROB1', module: 'MainModule', variable: 'nTestVar', interval: '100000' });
    await runInput(node, {});
    await flush();
    node._polling = false; if (node._timer) clearTimeout(node._timer);
    assert.strictEqual(node.sent.length, 0);
    assert.ok(node.errors.some(function(e) { return e.indexOf('not found') >= 0; }));
});

// gofa-rapid-var-read ────────────────────────────────────────────────────────
await checkAsync('gofa-rapid-var-read: uses the live socket value when the variable is known to GETVAR', async function() {
    var mockRobot = { socketSend: function(cmd) { return Promise.resolve('VAL:9.000000'); } };
    var node = new (loadNodeType('./nodes/gofa-rapid-var-read', { nodesById: { r1: mockRobot } }))({ robot: 'r1', variable: 'nTestVar' });
    var msg = {};
    await runInput(node, msg);
    assert.deepStrictEqual(msg.payload, { ok: true, variable: 'nTestVar', value: 9, source: 'socket' });
});
await checkAsync('gofa-rapid-var-read: falls back to module-text when GETVAR doesn\'t know the variable, flagged stale', async function() {
    var mockRobot = {
        socketSend: function() { return Promise.resolve('ERR:UNKNOWN_VAR'); },
        rwsGet: function(p) {
            if (p.indexOf('/text') >= 0) return Promise.resolve('<span class="file-path">TEMP/MainModule.mod</span>');
            return Promise.resolve('PERS num nOther := 42;');
        },
        parseXhtml: parseXhtml
    };
    var node = new (loadNodeType('./nodes/gofa-rapid-var-read', { nodesById: { r1: mockRobot } }))({ robot: 'r1', variable: 'nOther' });
    var msg = {};
    await runInput(node, msg);
    assert.strictEqual(msg.payload.ok, true);
    assert.strictEqual(msg.payload.value, '42');
    assert.strictEqual(msg.payload.source, 'module-text');
    assert.strictEqual(msg.payload.stale, true, 'module-text reads must be flagged stale — confirmed live to return the compiled value, not the current one');
    assert.ok(msg.payload.warning, 'should explain why the value may not be current');
});

// gofa-robot: createRobotClient session lifecycle (login/logout) ───────────
// A local mock RWS server standing in for the controller: any request with
// no Cookie header is treated as the Basic-Auth login (issues a fresh
// Set-Cookie), GET /logout is recorded separately, everything else with a
// Cookie header is just a plain authenticated 200.
function makeMockRwsServer() {
    var loginCount = 0, logoutCookies = [], cookieSeq = 0;
    var server = http.createServer(function(req, res) {
        if (req.url === '/logout') {
            logoutCookies.push(req.headers['cookie'] || null);
            res.writeHead(200); res.end(); return;
        }
        if (!req.headers['cookie']) {
            loginCount++; cookieSeq++;
            res.writeHead(200, { 'Set-Cookie': 'ABBCX=sess' + cookieSeq });
            res.end('<html></html>'); return;
        }
        res.writeHead(200); res.end('<html></html>');
    });
    return {
        server: server,
        loginCount: function() { return loginCount; },
        logoutCookies: function() { return logoutCookies; },
        listen: function() { return new Promise(function(resolve) { server.listen(0, function() { resolve(server.address().port); }); }); }
    };
}
await checkAsync('createRobotClient: logout releases the session and the next call re-authenticates', async function() {
    var mock = makeMockRwsServer();
    var port = await mock.listen();
    try {
        var client = createRobotClient({ ip: '127.0.0.1', rwsPort: port, socketPort: 1025, username: 'u', password: 'p' });

        var firstCookie = await client.getCookie();
        assert.strictEqual(mock.loginCount(), 1, 'first use must log in exactly once');
        assert.ok(firstCookie, 'a session cookie should be captured');

        await client.rwsGet('/rw/panel/ctrl-state');
        assert.strictEqual(mock.loginCount(), 1, 'reusing the session must not re-authenticate');

        await client.logout();
        assert.strictEqual(mock.logoutCookies().length, 1, 'logout must hit GET /logout exactly once');
        assert.strictEqual(mock.logoutCookies()[0], firstCookie, 'logout must send the session cookie being released');

        var secondCookie = await client.getCookie();
        assert.strictEqual(mock.loginCount(), 2, 'the next call after logout must re-authenticate');
        assert.notStrictEqual(secondCookie, firstCookie, 'a fresh session should replace the released one');
    } finally { mock.server.close(); }
});
await checkAsync('createRobotClient: logout is a no-op when no session was ever established', async function() {
    var hit = false;
    var server = http.createServer(function(req, res) { hit = true; res.writeHead(200); res.end(); });
    await new Promise(function(resolve) { server.listen(0, resolve); });
    try {
        var client = createRobotClient({ ip: '127.0.0.1', rwsPort: server.address().port, socketPort: 1025, username: 'u', password: 'p' });
        await client.logout();
        assert.strictEqual(hit, false, 'logout must not make any HTTP request if no session cookie exists');
    } finally { server.close(); }
});
await checkAsync('gofa-robot: node close calls logout and invokes done()', async function() {
    var mock = makeMockRwsServer();
    var port = await mock.listen();
    try {
        var GoFaRobot = loadNodeType('./nodes/gofa-robot', {});
        var node = new GoFaRobot({
            ip: '127.0.0.1', rwsPort: port, socketPort: 1025, username: 'u',
            pointsFile: path.join(tmpDir, 'gofa-robot-close-test.json'),
            credentials: { password: 'p' }
        });
        await node.rwsGet('/rw/panel/ctrl-state');
        assert.strictEqual(mock.loginCount(), 1, 'establishing a session should log in once');

        var doneCalled = false;
        await new Promise(function(resolve) {
            node._handlers['close'](function() { doneCalled = true; resolve(); });
        });
        assert.strictEqual(doneCalled, true, 'close handler must call done()');
        assert.strictEqual(mock.logoutCookies().length, 1, 'close must log out the session via GET /logout');
    } finally { mock.server.close(); }
});

fs.rmSync(tmpDir, { recursive: true, force: true });
console.log('\n' + passed + ' passed, ' + failed + ' failed.');
if (failed) process.exit(1);

})();
